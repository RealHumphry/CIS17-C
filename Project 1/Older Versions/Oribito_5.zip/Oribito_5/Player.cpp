/*
 * File:   Player.cpp
 * Author: Daniel
 * 
 * Created on November 11, 2023, 11:00 PM
 */

#include "Player.h"
#include <iostream>

using namespace std;

void Player::refill()
{
    player.push(1);
    player.push(2);
}
int Player::getTurn()
{
    int p = player.front();
    player.pop();
    if(player.empty()) refill();
    return p;
}
void Player::startTurn()
{
    int p = getTurn();
    cout << "Player " << p << "'s turn: " << endl;
    b.printBoard();
    b.editBoard(p);
    //b.orbit(); function to add in future
    if(b.findWin()) cout << "Somebody Won!" << endl;
}

