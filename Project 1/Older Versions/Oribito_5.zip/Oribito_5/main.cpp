/*
 *  file: main.cpp
 *  Author: Daniel Zarate
 *  Created on November 11, 2023
 *  Purpose: 5 Moved Queue into player class
 */
 //System Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <ctime> 
#include <queue>

#include "Player.h"

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) 
{

    //Set random seed
    srand(static_cast<unsigned int> (time(0)));
    /*
    Board b;
    b.printBoard();
    b.editBoard();
    b.printBoard();
    */
    
    Player p;
    for(int i = 0; i<5;i++)
        p.startTurn();
    
    
    

    
    //Exit the Program
    return 0;
}