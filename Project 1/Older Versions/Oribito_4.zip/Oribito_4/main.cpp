/*
 *  file: main.cpp
 *  Author: Daniel Zarate
 *  Created on November 11, 2023
 *  Purpose: Created Queue class and made ready to move into its own class
 */
 //System Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <ctime> 
#include <queue>

#include "Board.h"

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) 
{

    //Set random seed
    srand(static_cast<unsigned int> (time(0)));
    /*
    Board b;
    b.printBoard();
    b.editBoard();
    b.printBoard();
    */
    int i = 0;
    
    queue<int> player;
    //void refill() { what the refill function will look like when moved into a class
    player.push(1);
    player.push(2);
    //}
    
    Board b;
    while(i < 5){
        //if(player.empty()) refill(); function to run when made in class
        
        
        
        cout << "Player " << player.front() << "'s turn: " << endl;
        b.printBoard();
        b.editBoard(player.front());
        //b.orbit(); function to add in future
        if(b.findWin()) break;
        i++;
    }
    
    
    

    
    //Exit the Program
    return 0;
}