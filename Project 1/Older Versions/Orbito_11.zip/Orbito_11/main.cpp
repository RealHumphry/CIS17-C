/*
 *  file: main.cpp
 *  Author: Daniel Zarate
 *  Created on November 11, 2023
 *  Purpose: 11 Slight changes to main() and Player::startTurn()
 *              Created functions Board::movePiece() and 
 *              Board::hasAdjacent(), which uses find()
 */
 //System Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <ctime> 
#include <queue>

#include "Player.h"

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) 
{

    //Set random seed
    srand(static_cast<unsigned int> (time(0)));
    
    int numTurn = 0;
    Player p;
    
    while(p.startTurn(numTurn)) numTurn++;
    
    
    

    
    //Exit the Program
    return 0;
}