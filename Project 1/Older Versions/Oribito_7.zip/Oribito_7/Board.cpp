/*
 * File:   Board.cpp
 * Author: Daniel
 * 
 * Created on November 11, 2023, 7:06 PM
 */


#include "Board.h"
#include <iostream>
#include <stack>
#include <list>

using namespace std;

Board::Board()
{
    size = 16;
    
    for (int i = 1; i <= size; i++)
    {
        string s;
        char* temp = new char[2];
        temp[0] = (i-1)/4 + 'A';
        temp[1] = (i%4 == 0) ? 4 + '0' : (i % 4) + '0';
        s.append(temp);
        
        board.insert(make_pair(s, ' '));
    }
}
void Board::printBoard()
{
    int perLine = 4;
    
    map<string, char>::iterator it;
    int i = 0;
    cout << endl;
    cout << "      1  2  3  4" << endl;
    cout << "    -------------";
    for (it = board.begin(); it != board.end(); it++)
    {
        if (i % perLine == 0) cout << endl << "  " << static_cast<char>(i/perLine + 'A') << " | ";
        cout << it->second << "  ";
        i++;
    }
    cout << endl << endl;
}
void Board::editBoard(int p)
{
    string key;
    cout << "enter map key  "; 
    cin >> key;
    cout << endl;
    if(board.count(key)==0){cout << "NOT FOUND!"; return;}
    
    board[key] = p==1? 'X':'O';
}

void Board::orbit()
{
    map<string, char>::iterator it = board.begin();
    stack<char> sfil;
    list<char> lfil;
    list<char>::iterator lit;
    
    
    //outer square fill stack
    for(int i = 0; i < 4; i++){     //read A-row (1-4)
        sfil.push((it++)->second);
    }
    it--;
    for(int i = 0; i < 3; i++){     //read 4-col (B-D)
        it = next(it, 4);
        sfil.push(it->second);
    }
    for(int i = 0; i < 3; i++){     //read D-row (1-3)
        sfil.push((--it)->second);
    }
    for(int i = 0; i < 2; i++){     //read 1-col (B-C)
        it = next(it, -4);
        sfil.push(it->second);
    }
    
    //put back stack into map with orbit completed
    it = next(it,4);            //B1->C1
    it->second = sfil.top(); 
    sfil.pop();
    
    it = next(it, 4);
    for(int i = 0; i<4; i++){   //move D-row (1-4)
        (it++)->second = sfil.top();
        sfil.pop();
        
    }
    it--;
    for(int i = 0; i<3; i++){   //move 4-col (A-C)
        it = next(it, -4);
        it->second = sfil.top();
        sfil.pop();
    }
    for(int i = 0; i<3; i++){   //move A-row (1-3)
        (--it)->second = sfil.top();
        sfil.pop();
    }
    it = next(it, 4);       //A1->B1
    it->second = sfil.top();
    sfil.pop();
        
    //it->first == B1 (this is true)
    
    //inner square orbit
    for(int i = 0;i<2;i++){     //read b-row (2 and 3)
        lfil.push_back((++it)->second);
    }
    it = next(it, 2);
    for(int i = 0;i<2;i++){     //read c-row (2 and 3)
        lfil.push_back((++it)->second);
    }
    
    
    //paste list elements back into map with orbit
    lit = lfil.begin();     //B2->C2
    (--it)->second = *lit;
    
    it = next(it,-4);       //B3->B2
    it->second = *(++lit);
    
    lit = lfil.end();       //C3->B3 
    (++it)->second = *(--lit);
    
    it = next(it, 4);       //C2->C3
    it->second = *(--lit);
}

int Board::findWin()
{
    int w, p1W=0, p2W=0; //# of wins from each player
    string spos; //start pos for checking
    //check down each column
    spos = "A1";
    for(int i = 1; i<=4; i++)
    {
        spos = spos.at(0);
        spos += i+'0';
        w = checkLine(spos, 1, 0); 
        if(w==1) p1W++;
        else if(w==2) p2W++;
    }
    
    //check each row going right
    spos = "A1";
    for(int i = 1; i<=4; i++)
    {
        spos = i-1+'A';
        spos += '1';
        w = checkLine(spos, 0, 1); 
        if(w==1) p1W++;
        else if(w==2) p2W++;
        
    }
    
    //check diagonal (like this \)
    spos = "A1";
    w = checkLine(spos, 1, 1); 
    if(w==1) p1W++;
    else if(w==2) p2W++;
    
    //check diagonal (like this /)
    spos = "A4";
    w = checkLine(spos, 1, -1); 
    if(w==1) p1W++;
    else if(w==2) p2W++;
    
    
    if(p1W>p2W) return 1;               //PLAYER 1 WINS
    if(p1W<p2W) return 2;               //PLAYER 2 WINS
    if(p1W != 0 && p2W != 0) return 3;  //DRAW
    return 0;                           //still no winner
}

int Board::checkLine(string start, int rDif, int cDif)
{
    //first check if empty (no player has occupied this slot yet)
    if(board[start] == ' ')return 0;
    
    char comp;
    char row, col;
    
    comp = board[start];    
    for(int i = 2;i<=4;i++)
    {
        row = start.at(0);
        col = start.at(1);
        start = rDif+ row; 
        start += cDif + col;
        
        if(board[start] != comp) return 0;
    }
    if(comp == 'X') return 1;
    if(comp == 'Y')return 2;
}