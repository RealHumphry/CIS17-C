/*
 * File:   Board.cpp
 * Author: Daniel
 * 
 * Created on November 11, 2023, 7:06 PM
 */

#include <iostream>

#include "Board.h"


using namespace std;

Board::Board()
{
    size = 16;
    
    for (int i = 1; i <= size; i++)
    {
        board.insert(make_pair(i, ' '));
    }
}
void Board::printBoard()
{
    int perLine = 4;
    
    map<int, char>::iterator it;
    int i = 0;
    cout << endl << endl;
    cout << "     A  B  C  D" << endl;
    cout << "   -------------";
    for (it = board.begin(); it != board.end(); it++)
    {
        if (i % perLine == 0) cout << endl << "  " << (i + perLine) / perLine << "| ";
        cout << it->second << "  ";
        i++;
    }
    cout << endl << endl;
}
void Board::editBoard()
{
    int key;
    char val;
    cout << "enter map key  "; cin >> key;
    cout << endl;
    if(board.count(key)==0){cout << "NOT FOUND!"; return;}
    
    cout << "enter map new value  "; cin >> val;
    
    board[key] = val;
}
bool Board::checkWin()
{
    int pos;
    char comp;
    bool winning;
    //start in top left corner
    //check right
    pos = 1;
    comp = board[pos];
    do
    {
        pos++;
        if(comp!=board[pos]) winning = false; 
    }while(winning);
    
    //check down
    pos = 1;
    comp = board[pos];
    do
    {
        pos+=4;
        if(comp!=board[pos]) winning = false; 
    }while(winning);
    
    //check diagonal
    pos = 1;
    comp = board[pos];
    do
    {
        pos+= 5;
        if(comp!=board[pos]) winning = false; 
    }while(winning);
    
    
    return false;
}