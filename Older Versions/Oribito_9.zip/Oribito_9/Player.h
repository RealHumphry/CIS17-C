/*
 * File:   Player.h
 * Author: Daniel
 *
 * Created on November 11, 2023, 11:00 PM
 */

#ifndef PLAYER_H
#define PLAYER_H
#include "Board.h"
#include <queue>

class Player {
    
private:    
    queue<int> player;
    Board b;
    
public:
    Player(){refill();}
    void refill();
    int getTurn();
    int startTurn();
    


};

#endif /* PLAYER_H */

