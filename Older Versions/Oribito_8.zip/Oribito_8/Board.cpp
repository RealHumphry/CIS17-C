/*
 * File:   Board.cpp
 * Author: Daniel
 * 
 * Created on November 11, 2023, 7:06 PM
 */


#include "Board.h"
#include <iostream>
#include <stack>
#include <list>

using namespace std;

Board::Board()
{
    size = 16;
    
    for (int i = 1; i <= size; i++)
    {
        string s;
        char* temp = new char[2];
        temp[0] = (i-1)/4 + 'A';
        temp[1] = (i%4 == 0) ? 4 + '0' : (i % 4) + '0';
        s.append(temp);
        
        board.insert(make_pair(s, ' '));
    }
}
void Board::printBoard()
{
    int perLine = 4;
    
    map<string, char>::iterator it;
    int i = 0;
    cout << endl;
    cout << "      1  2  3  4" << endl;
    cout << "    -------------";
    for (it = board.begin(); it != board.end(); it++)
    {
        if (i % perLine == 0) cout << endl << "  " << static_cast<char>(i/perLine + 'A') << " | ";
        cout << it->second << "  ";
        i++;
    }
    cout << endl << endl;
}
void Board::editBoard(int p)
{
    string key;
    cout << "enter map key  "; 
    cin >> key;
    cout << endl;
    if(board.count(key)==0){cout << "NOT FOUND!"; return;}
    
    board[key] = p==1? 'X':'O';
}

void Board::orbit()
{
    map<string, char>::iterator it = board.begin();
    stack<char> sfil;
    list<char> lfil;
    list<char>::iterator lit;
    
    
    //outer square fill stack
    for(int i = 0; i < 4; i++){     //read A-row (1-4)
        sfil.push((it++)->second);
    }
    it--;
    for(int i = 0; i < 3; i++){     //read 4-col (B-D)
        it = next(it, 4);
        sfil.push(it->second);
    }
    for(int i = 0; i < 3; i++){     //read D-row (1-3)
        sfil.push((--it)->second);
    }
    for(int i = 0; i < 2; i++){     //read 1-col (B-C)
        it = next(it, -4);
        sfil.push(it->second);
    }
    
    //put back stack into map with orbit completed
    it = next(it,4);            //B1->C1
    it->second = sfil.top(); 
    sfil.pop();
    
    it = next(it, 4);
    for(int i = 0; i<4; i++){   //move D-row (1-4)
        (it++)->second = sfil.top();
        sfil.pop();
        
    }
    it--;
    for(int i = 0; i<3; i++){   //move 4-col (A-C)
        it = next(it, -4);
        it->second = sfil.top();
        sfil.pop();
    }
    for(int i = 0; i<3; i++){   //move A-row (1-3)
        (--it)->second = sfil.top();
        sfil.pop();
    }
    it = next(it, 4);       //A1->B1
    it->second = sfil.top();
    sfil.pop();
        
    //it->first == B1 (this is true)
    
    
    // THIS CAN BE CHANGED TO USE swap() MUTATING ALGORTIHM 
    //inner square orbit
    for(int i = 0;i<2;i++){     //read b-row (2 and 3)
        lfil.push_back((++it)->second);
    }
    it = next(it, 2);
    for(int i = 0;i<2;i++){     //read c-row (2 and 3)
        lfil.push_back((++it)->second);
    }
    
    
    //paste list elements back into map with orbit
    lit = lfil.begin();     //B2->C2
    (--it)->second = *lit;
    
    it = next(it,-4);       //B3->B2
    it->second = *(++lit);
    
    lit = lfil.end();       //C3->B3 
    (++it)->second = *(--lit);
    
    it = next(it, 4);       //C2->C3
    it->second = *(--lit);
}

int Board::findWin()
{
    //this function can be changed to use sets and using equal algorithm function
    
    int w, p1W=0, p2W=0; //# of wins from each player
    map<string, char>::iterator it, it2;
    
    //check down each column
    for(int i=0; i<4; i++)
    {
        it = next(board.begin(), i);
        if(it->second != ' '){
            bool match = true;
            for(int j=1;j<=3;j++)
            {
                it2 = next(it, 4*j);
                if(it2->second != it->second) match = false;
            }
            if(match){
                if(it->second == 'X') p1W++; //player 1 has 4 in a row
                else p2W++; //player 2 has 4 in a row
            }
        }
    }
    
    //check each row left to right
    for(int i=0; i<4; i++)
    {
        it = next(board.begin(), i*4);
        if(it->second != ' '){
            bool match = true;
            for(int j=1; j<=3; j++)
            {
                it2 = next(it, j);
                if(it2->second != it->second) match = false;
            }
            if(match){
                if(it->second == 'X') p1W++; //player 1 has 4 in a row
                else p2W++; //player 2 has 4 in a row
            }
        }
    }
    
    //check diagonal (like this \)
    it=board.begin();
    if(it->second!=' '){
        bool match = true;
        for(int i=1; i<=3; i++)
        {
            it2 = next(it, 5*i);
            if(it2->second != it->second) match = false;
        }
        if(match){
            if(it->second=='X') p1W++;
            else p2W++;
        }
    }
    
    //check diagonal (like this /)
    it= next(board.begin(), 3);
    if(it->second!=' '){
        bool match = true;
        for(int i=1; i<=3; i++)
        {
            it2 = next(it, i*3);
            if(it2->second != it->second) match = false;
        }
        if(match){
            if(it->second=='X') p1W++;
            else p2W++;
        }
    }
    
    
    if(p1W>p2W) return 1;               //PLAYER 1 WINS
    if(p1W<p2W) return 2;               //PLAYER 2 WINS
    if(p1W != 0 && p2W != 0) return 3;  //DRAW
    return 0;                           //still no winner
}