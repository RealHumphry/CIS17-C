/*
 *  file: main.cpp
 *  Author: Daniel Zarate
 *  Created on November 11, 2023
 *  Purpose: Create and print board
 */
 //System Libraries
#include <cstdlib>
#include <iostream>
#include <iomanip>
#include <ctime> 
#include <map>

using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here
int main(int argc, char** argv) {

    const int BOARD_SIZE = 16;
    int perLine = 4;
    //Set random seed
    srand(static_cast<unsigned int> (time(0)));



    map<char*, char> board;
    map<char*, char>::iterator it;


    for (int i = 1; i <= BOARD_SIZE; i++)
    {
        char* pos = new char[3];
        pos[0] = (i-1)/4 + 'A';
        pos[1] = (i%4 == 0) ? 4 + '0' : (i % 4) + '0';
        pos[2] = '\0';
        board.insert(make_pair(pos, 'X'));
    }




    int i = 0;
    cout << "     A  B  C  D" << endl;
    cout << "   -------------";
    for (it = board.begin(); it != board.end(); it++)
    {
        if (i % perLine == 0) cout << endl << "  " << (i + perLine) / perLine << "| ";
        cout << it->second << "  ";
        i++;
    }
    cout << endl << endl;
   
    
    i = 0;
    cout << "     A  B  C  D" << endl;
    cout << "   -------------";
    for (it = board.begin(); it != board.end(); it++)
    {
        if (i % perLine == 0) cout << endl << "  " << (i + perLine) / perLine << "| ";
        cout << it->first << "  ";
        i++;
    }
    cout << endl << endl;


    
    char* key = new char[2]; //way bigger than necessary 
    int val;
    cout << "enter map key  "; cin >> key;
    cout << endl;
    
    cout << "enter map new value  "; cin >> val;
    if(board.count(key)==0){cout << "NOT FOUND!";return 0;}
    board[key] = val;


    i = 0;
    cout << "     A  B  C  D" << endl;
    cout << "   -------------";
    for (it = board.begin(); it != board.end(); it++)
    {
        if (i % perLine == 0) cout << endl << "  " << (i + perLine) / perLine << "| ";
        cout << it->second << "  ";
        i++;
    }
    cout << endl << endl;

    //free memory
    delete [] key;
    //Exit the Program
    return 0;
}